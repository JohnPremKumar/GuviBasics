/*

WHAT IS THIS?

This module demonstrates simple uses of Botkit's conversation system.

In this example, Botkit hears a keyword, then asks a question. Different paths
through the conversation are chosen based on the user's response.

*/
const { Client } = require('pg');

module.exports = function(controller) {

    controller.hears(['hi','hello','howdy','hey'],'direct_message,direct_mention',function(bot,message) {

        bot.startConversation(message, function(err, convo) {
            convo.ask('Hi, what can i do for you?', function(response, convo){
                if(response.text != "help"){
                    convo.say("Hey, Can not understand what \"" + response.text + "\" is");
                    convo.say("Try `@topbot help` to see the available actions");
                }
                else{
                    convo.say(help());
                }
                convo.next();
            });
        });

    });

    function help(){
        return "`@topbot launch` : This command is used to create new task.\nUsage : @topbot launch [a detailed description of the task i want to launch.  For examples, I need a graphic to show XYZ, add unit testing to the code located here, etc....\n\n`@topbot accept` : This command is used to accept the challenges posted in the quotes channel by repling to the task you do in thread. \nUsage : @topbot accept\n\n`@topbot approve` : This command is used by the launcher / client to accepts the work. \nUsage : @topbot approve";
    }

    controller.hears(['help'],'direct_message,direct_mention',function(bot,message){

        bot.startConversation(message, function(err, convo){
            convo.say(help());
        });

    });

    controller.hears(['launch'],'direct_mention',function(bot,message){
        bot.startConversation(message, function(err, convo){
            let msg = message.text.substr(7);
            if(msg != ""){
                let data = "Below are the task details : \n" + message.text.substr(7) + "\n\n Created By User: <@" + message.event.user + ">\n User id : `<" + message.event.user + ">`";
                bot.api.chat.postMessage({channel : "CHVA99Q3S", text : data},function(err,response) {
                    if(response.ok){
                        convo.say("Task posted in the channel #quote successfully");
                    }
                });
            }
            else{
                convo.say("Task Details Can not be empty\n\n Need help? Type `@topbot help` to know the Usecase");
            }
            
        });
    });

    controller.hears(['accept'],'direct_mention',function(bot, message){
        
        bot.startConversation(message, function(err, convo){
            if(message.event.thread_ts){
                bot.api.channels.replies({token: bot.config.bot.app_token, channel : message.event.channel, thread_ts : message.event.thread_ts}, function(err, response){
                    if(response.messages[0].bot_id && response.messages[0].text.includes("Below are the task details :")){
                        let initiatorId = response.messages[0].text.slice(response.messages[0].text.indexOf("`&lt;")+5,response.messages[0].text.lastIndexOf("&gt;`"));
                        let acceptorId = message.event.user;
                        let botId = "UHZ6B104E";
                        if(initiatorId != acceptorId){
                            let channelName = "new-channel" + randomNumber();
                            let data = response.messages[0].text;

                            const client = new Client({
                                connectionString: process.env.DATABASE_URL,
                                ssl: true,
                            });

                            client.connect();

                            client.query('SELECT * FROM topbot WHERE task_hash = $1 AND accepted_user = $2 AND created_user = $3', [data, acceptorId, initiatorId], function(err, res) {
                                if (err) throw err;
                                let result = res.rows.length;
                                client.end();
                                console.log(result);
                                if(result == 0){
                                    bot.api.channels.create({token: bot.config.bot.app_token, name : channelName}, function(err, response){
                                        invite(bot, initiatorId, response.channel.id);
                                        invite(bot, botId, response.channel.id);
                                        invite(bot, acceptorId, response.channel.id);
                            
                                        bot.api.chat.postMessage({channel : response.channel.id, text : data},function(err,response) {
                                            if(response.ok){
                                            insertData(data, acceptorId, initiatorId);
                                                convo.say("Task is accepted successfully. A channel is created with the name #" + channelName + " and the task details are shared there for further reference");
                                            }
                                        });
                                    }); 
                                }
                                else{
                                    convo.say("You have already acccepted this task. Kindly check for the channels that are already created while acceptance is confirmed for further actions");
                                }
                            });
                        }
                        else{
                            convo.say("The task is created by you. Thus, only others can perform this action\n\n Try `@topbot help` for more information");
                        }
                    }
                    else{
                        convo.say("This action can be only performed as a reply to the task posted\n\n Not sure how? Type `@topbot help` to know more");
                    }
                });
                //bot.api.channels.create({namsfe : message},function(err, response){});
            }
            else{
                convo.say("This command can be used only in threads as a reply to the task posted.\n\n Try `@topbot help` for more information");    
            }
        });
    });

    controller.hears(['approve'],'direct_mention',function(bot, message){
        bot.startConversation(message, function(err, convo){
            convo.say("Great we'll get your work done. Now you can sit back and relax");
        });
    });


    function selectData(data, acceptorId, initiatorId){
        const client = new Client({
            connectionString: process.env.DATABASE_URL,
            ssl: true,
        });

        client.connect();

        client.query('SELECT * FROM topbot WHERE task_hash = $1 AND accepted_user = $2 AND created_user = $3', [data, acceptorId, initiatorId], function(err, res) {
            if (err) throw err;
            let result = res.rows.length;
            client.end();
            if(result > 0){
                console.log("true");
                return true;
            }
        });
    }

    function insertData(data, acceptorId, initiatorId){
        const client = new Client({
            connectionString: process.env.DATABASE_URL,
            ssl: true,
        });

        client.connect();

        client.query('INSERT INTO topbot (task_hash, accepted_status, accepted_user, created_user) VALUES ($1,$2,$3,$4)', [data, "yes", acceptorId, initiatorId], function(err, res) {
            if (err) throw err;
            console.log(res);
            client.end();
        });
    }

    function invite(bot, userId, channelId){
        bot.api.channels.invite({token: bot.config.bot.app_token, channel : channelId, user : userId}, function(err, response){
        });
    }

    function randomNumber(){
        return Math.ceil(Math.random()*1000);
    }

    function getUserName(bot, id){
        bot.api.users.info({user : id},function(err, response){
            return response;
        });
    }

    function getChannelName(bot, id){
        bot.api.channels.info({channel : id},function(err, response){
            return response;
        });
    }

    controller.hears(['color'], 'direct_message,direct_mention', function(bot, message) {

        bot.startConversation(message, function(err, convo) {
            convo.say('This is an example of using convo.ask with a single callback.');

            convo.ask('What is your favorite color?', function(response, convo) {

                convo.say('Cool, I like ' + response.text + ' too!');
                convo.next();

            });
        });

    });


    controller.hears(['question'], 'direct_message,direct_mention', function(bot, message) {

        bot.createConversation(message, function(err, convo) {

            // create a path for when a user says YES
            convo.addMessage({
                    text: 'How wonderful.',
            },'yes_thread');

            // create a path for when a user says NO
            // mark the conversation as unsuccessful at the end
            convo.addMessage({
                text: 'Cheese! It is not for everyone.',
                action: 'stop', // this marks the converation as unsuccessful
            },'no_thread');

            // create a path where neither option was matched
            // this message has an action field, which directs botkit to go back to the `default` thread after sending this message.
            convo.addMessage({
                text: 'Sorry I did not understand. Say `yes` or `no`',
                action: 'default',
            },'bad_response');

            // Create a yes/no question in the default thread...
            convo.ask('Do you like cheese?', [
                {
                    pattern:  bot.utterances.yes,
                    callback: function(response, convo) {
                        convo.gotoThread('yes_thread');
                    },
                },
                {
                    pattern:  bot.utterances.no,
                    callback: function(response, convo) {
                        convo.gotoThread('no_thread');
                    },
                },
                {
                    default: true,
                    callback: function(response, convo) {
                        convo.gotoThread('bad_response');
                    },
                }
            ]);

            convo.activate();

            // capture the results of the conversation and see what happened...
            convo.on('end', function(convo) {

                if (convo.successful()) {
                    // this still works to send individual replies...
                    bot.reply(message, 'Let us eat some!');

                    // and now deliver cheese via tcp/ip...
                }

            });
        });

    });

};
